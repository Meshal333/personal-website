<?php
	$con = mysqli_connect("localhost","root","","cuisine_world");
	?>
	